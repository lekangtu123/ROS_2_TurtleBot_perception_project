#!/bin/bash

echo "LD_LIBRARY_PATH = '$LD_LIBRARY_PATH'"
echo "PATH = '$PATH'"
