
def printHello():
    print('Hi from enpm673 module.')


